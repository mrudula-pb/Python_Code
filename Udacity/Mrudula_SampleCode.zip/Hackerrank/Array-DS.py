
import math
import os
import random
import re
import sys


# Complete the reverseArray function below.
def reverseArray(a):
    if __name__ == '__main__':
        fptr = open(os.environ["/home/mdot/Desktop/test.txt"], 'w')
        print("dbvsdbhjfbasjfbasdh")
        print(fptr)
        arr_count = int(input())
        print(arr_count)

        arr = list(map(int, input().rstrip().split()))

        print(arr)

        res = reverseArray(arr)

        fptr.write(' '.join(map(str, res)))
        fptr.write('\n')

        fptr.close()

reverseArray(4)